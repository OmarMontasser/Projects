X00 = [0.1; 0; 0.15];
Xff = [0.2; 0.2; 0.05];
Tff = 5; 
Tss = 0.1;

Task_Space = task_traj_circle(X00, Xff, Tff, Tss);
disp(Task_Space);

% Visualize the trajectory
plot3(Task_Space(:,1), Task_Space(:,2), Task_Space(:,3), '-o');
xlabel('X'); ylabel('Y'); zlabel('Z');
grid on;
title('3D Trajectory');
