function qmatrix = Traj_genration_func(X0, Xf, Tf, Ts)
X_matrix = task_traj_circle(X0, Xf, Tf, Ts);
qmatrix = zeros(size(X_matrix));
[m, n] = size(X_matrix);
q0 = [ 1 ;50; 1];
for i = 1:m
   X_desired = X_matrix(i, :)
   q = inverse_kinematics_func(q0, X_desired);
   X_actual = forward_Position_kinematics(q(1),q(2),q(3));
   q(1)=getin_scale(q(1));
   q(3)=getin_scale(q(3));
   qmatrix(i, :) = q;
   q0= q;
end

end