function q_dot = inverse_velocity(q, X_dot)
    % Obtain the Jacobian matrix for the current joint configuration
    
    J_inv = inverse_jacobian_matrix(q);
    
    % Compute joint velocities (q_dot) by multiplying the Jacobian inverse with the desired end-effector velocity
    q_dot = J_inv * X_dot;
end