function generate_jacobian()
    % Define symbolic variables
    syms q1 q2 q3 real
    L1 = 0.645*1000;
    L2 = 0.228*1000;
    L3 = 0.1365*1000;
    L4 = L1 + (0.1 - 0.031+0.025)*1000;

    % Calculate forward kinematics position
    X = forward_Position_kinematics(q1, q2, q3);
    
    % Compute Jacobian matrix
    J = jacobian(X, [q1; q2; q3]);
    
    % Convert symbolic Jacobian to a MATLAB function file
    matlabFunction(J, 'File', 'numeric_jacobian_func', 'Vars', [q1; q2; q3]);
end