% Parameters
scale = 6; % Scale for a smaller heart (~50 mm wide)
center_x = 200; % Offset X position in mm
center_y = 200; % Offset Y position in mm
z_height = 0; % Cutting plane height in mm
down_height = 0; % Lower Z height in mm for cutting
initial_height = 40; % Initial Z height in mm
num_points = 100; % Number of points for a smooth heart

% Parametric equations for heart shape
t = linspace(0, 2*pi, num_points); % Parameter t
x_traj = scale * 16 * sin(t).^3 + center_x; % X coordinates
y_traj = scale * (13 * cos(t) - 5 * cos(2*t) - 2 * cos(3*t) - cos(4*t)) + center_y; % Y coordinates
z_traj = z_height * ones(1, num_points); % Z height remains constant for the heart

% Initial descent and final ascent points
descent = [center_x, center_y, initial_height;center_x, center_y, initial_height; center_x, center_y, down_height];
ascent = [center_x, center_y, down_height; center_x, center_y, initial_height];

% Combine the trajectory: descent -> heart -> ascent
trajectory = [descent; [x_traj', y_traj', z_traj']; ascent];

% Plot the trajectory in 3D space
figure;
plot3(trajectory(:, 1), trajectory(:, 2), trajectory(:, 3), 'r-', 'LineWidth', 2);
grid on;
xlabel('X (mm)');
ylabel('Y (mm)');
zlabel('Z (mm)');
title('Heart-Shaped Trajectory with Descent and Ascent');
axis equal;

% Initialize joint variables
q1_values = [];
q2_values = [];
q3_values = [];
q0 = [0.1; 0.3; 2]; % Initial guess for inverse kinematics
contiuscycle = false;

% Compute joint variables for the entire trajectory
for i = 1:size(trajectory, 1)
    % Extract desired end-effector position
    Px = trajectory(i, 1) / 1000; % Convert mm to m
    Py = trajectory(i, 2) / 1000; % Convert mm to m
    Pz = trajectory(i, 3) / 1000; % Convert mm to m

    % Inverse kinematics for RPR SCARA robot
    qq = inverse_kinematics_func(q0, [Px * 1000; Py * 1000; Pz * 1000]);
    if contiuscycle
        qtemp = q0;
        while (abs(qq(1) - qtemp(1)) > 0.5 || abs(qq(3) - qtemp(3)) > 0.5)
            q0 = [2 * pi * rand; 0.3; 2 * pi * rand];
            qq = inverse_kinematics_func(q0, [Px * 1000; Py * 1000; Pz * 1000]);
        end
    end

    % Store the joint values
    q1_values = [q1_values; qq(1)];
    q2_values = [q2_values; qq(2)];
    q3_values = [q3_values; qq(3)];

    q0 = qq; % Update the initial guess
    contiuscycle = true;
end

% Define time vector
time = linspace(0, 20, size(trajectory, 1))'; % Simulate for 20 seconds

% Create timeseries for joint variables
q1_ts = timeseries(q1_values, time);
q2_ts = timeseries(q2_values, time);
q3_ts = timeseries(q3_values, time);

% Save to .mat file for Simscape use
save('heart_trajectory_with_z_motion.mat', 'q1_ts', 'q2_ts', 'q3_ts');
