def sysCall_init():
    sim = require('sim')
    import math  # Import the math module for trigonometric functions
    
    # Initialization: Get handles for the two revolute joints
    self.joint1_handle = sim.getObject('../J1')
    self.joint2_handle = sim.getObject('../J3')
    
    # Define the heart trajectory
    self.num_steps = 250  # Number of time steps
    self.trajectory_time = [i * 0.1 for i in range(self.num_steps)]  # 10 seconds total
    t_values = [2 * math.pi * i / (self.num_steps - 1) for i in range(self.num_steps)]
    
    # Parametric heart trajectory equations
    x_raw = [16 * math.sin(t)**3 for t in t_values]
    y_raw = [13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t) for t in t_values]
    
    # Scaling and shifting the heart to fit in front of the robot
    scale_factor = 0.15  # Scale the heart to fit within a smaller area
    x_offset = 3.8   # Shift the heart 0.3 units in front of the robot
    y_offset = 1   # Center the heart 0.1 units above the base plane
    
    x = [scale_factor * x + x_offset for x in x_raw]
    y = [scale_factor * y + y_offset for y in y_raw]
    
    # Map the trajectory to the desired joint ranges
    # First joint: -pi/4 to pi/4 (90 degrees total)
    self.joint1_angles = [max(min(math.atan2(y[i], x[i]), math.pi / 4), -math.pi / 4) for i in range(self.num_steps)]
    
    # Second joint: scaled distance to keep movement within reachable workspace
    self.joint2_angles = [math.sqrt(x[i]**2 + y[i]**2) / 2.0 for i in range(self.num_steps)]
    
    # Initialize time and step index
    self.start_time = sim.getSimulationTime()
    self.current_step = 0


def sysCall_actuation():
    # Check if there are still trajectory points to process
    if self.current_step < len(self.trajectory_time):
        # Get the current simulation time
        current_sim_time = sim.getSimulationTime() - self.start_time
        
        # Check if it's time to update the joint positions
        if current_sim_time >= self.trajectory_time[self.current_step]:
            # Set joint target positions
            sim.setJointTargetPosition(self.joint1_handle, self.joint1_angles[self.current_step])
            sim.setJointTargetPosition(self.joint2_handle, self.joint2_angles[self.current_step])
            
            # Move to the next trajectory step
            self.current_step += 1


def sysCall_sensing():
    # Optional: Add sensing code if required
    pass


def sysCall_cleanup():
    # Optional: Add cleanup code if required
    pass
