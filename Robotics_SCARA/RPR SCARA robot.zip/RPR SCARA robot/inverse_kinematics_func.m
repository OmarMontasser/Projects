function q = inverse_kinematics_func(q0, X_desired)
    % Set tolerance and max iterations for the inverse kinematics solver
    tolerance = 1e-6;
    max_iterations = 100;
    q = q0; % Initial guess for joint angles
    for i = 1:max_iterations
        % Compute the current end effector position using forward kinematics
        X_current = forward_Position_kinematics(q(1), q(2), q(3)) ; % Assuming forward kinematics function for 3-joint robot    
        error = X_desired' - X_current';
        error = error(:) ; % This should convert the error to a column vector if needed
        % Break if the error is below the specified tolerance
        if norm(error) < tolerance
            break;
        end 
        J_inv = inverse_jacobian_matrix(q);  % Assuming inverse_jacobian_matrix returns a 3x3 matrix
         q = q + J_inv * error;
         q(1) = getin_scale(q(1)); % to be between 0 - 2pi
         q(3) = getin_scale(q(3));
    end
end