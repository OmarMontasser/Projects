import numpy as np

def task_traj_line(X0, Xf, Tf, Ts):
    """
    Generate a linear trajectory between two points.

    Parameters:
    X0 : list or array-like
        Initial position as [x0, y0, z0].
    Xf : list or array-like
        Final position as [xf, yf, zf].
    Tf : float
        Total time for trajectory (seconds).
    Ts : float
        Sampling time (seconds).

    Returns:
    numpy.ndarray
        A matrix containing the trajectory points in task space.
    """
    # Create a time vector
    t = np.arange(0, Tf + Ts, Ts)  # Include Tf in the range
    num_points = len(t)

    # Preallocate Task_Space matrix
    Task_Space = np.zeros((num_points, 3))

    # Compute linear interpolation for each coordinate
    for i in range(3):
        Task_Space[:, i] = np.linspace(X0[i], Xf[i], num_points)

    return Task_Space









def traj_generation_func_line(X0, Xf, Tf, Ts):
    """
    Generate joint configurations for a linear trajectory.

    Parameters:
    X0 : list or array-like
        Initial position as [x0, y0, z0].
    Xf : list or array-like
        Final position as [xf, yf, zf].
    Tf : float
        Total time for trajectory (seconds).
    Ts : float
        Sampling time (seconds).

    Returns:
    numpy.ndarray
        A matrix containing the joint configurations.
    """
    # Generate the task space trajectory
    X_matrix = task_traj_line(X0, Xf, Tf, Ts)
    # Initialize the joint configuration matrix
    qmatrix2 = np.zeros(X_matrix.shape)
    
    m, n = X_matrix.shape
    
    # Initial joint configuration
    q0 = np.array([1.0, 50.0, 1.0])
    
    for i in range(m):
        X_desired = X_matrix[i, :]
        
        # Compute joint angles using inverse kinematics
        q = inverse_kinematics_func(q0, X_desired)
        
        # Compute actual position from joint angles (optional, for validation)
        X_actual = forward_position_kinematics(q[0], q[1], q[2])
        
        # Store the joint angles
        qmatrix2[i, :] = q
        
        # Update the previous joint configuration
        q0 = q
        
    return qmatrix2
