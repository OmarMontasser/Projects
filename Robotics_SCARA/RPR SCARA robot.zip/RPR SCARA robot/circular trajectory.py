import numpy as np
def sysCall_init():
    global dataaa

    sim = require('sim')
    self.q1_handle = sim.getObject("../J1")
    self.q2_handle = sim.getObject("../J2")
    self.q3_handle = sim.getObject("../J3")
   # self.q4_handle = sim.getObject("../EEJ")
    
    X0 = [0.001, 0, 0.66]
    Xf = [0.3, 0, 0.4]
    Tf = 9.7
    Ts = 0.1

    trajectory = task_space(X0, Xf, Tf, Ts)
    #print("Task Space Trajectory:")
    #for i in range (len(trajectory)):
      #print(trajectory[i])
    self.q1_handle = sim.getObject("../J1")
    self.q2_handle = sim.getObject("../J2")
    self.q3_handle = sim.getObject("../J3")
    #self.q4_handle = sim.getObject("../EEJ")
    
    self.target_position1 = 0 * (3.14 / 180)  
    self.target_position2 = 0 * (3.14 / 180)  
    self.target_position3 = 0 * (3.14 / 180)
   # self.target_position4 = 0 * (3.14 / 180)

    global start_time
    start_time = sim.getSimulationTime()
    self.curr_time = start_time
    self.previous_time= sim.getSimulationTime() - start_time
    self.j=1
    
    dataaa =np.array([
    [0.0174533, -0.0624536, 0.121533],
    [0.0390954, -0.147591, 0.297796],
    [0.185462, -0.201471, 0.417112],
    [0.140987, -0.234317, 0.494316],
    [0.229982, -0.264736, 0.567121],
    [0.26474, -0.289822, 0.630478],
    [0.315735, -0.311523, 0.687822],
    [0.362102, -0.330216, 0.740236],
    [0.408286, -0.346351, 0.78861],
    [0.453218, -0.360185, 0.833556],
    [0.496922, -0.371911, 0.875515],
    [0.539295, -0.381662, 0.914818],
    [0.580292, -0.389537, 0.951711],
    [0.619887, -0.395611, 0.986383],
    [0.658076, -0.399942, 1.01898],
    [0.69487, -0.402575, 1.04961],
    [0.730293, -0.403552, 1.07836],
    [0.764378, -0.40291, 1.10529],
    [0.797167, -0.400683, 1.13047],
    [0.828705, -0.396909, 1.15392],
    [0.859045, -0.391626, 1.17569],
    [0.888237, -0.384877, 1.1958],
    [0.916335, -0.376709, 1.21428],
    [0.943394, -0.367172, 1.23114],
    [0.969468, -0.356325, 1.24642],
    [0.994608, -0.34423, 1.26015],
    [1.01887, -0.330957, 1.27234],
    [1.04229, -0.31658, 1.28304],
    [1.06494, -0.301179, 1.29228],
    [1.08684, -0.28484, 1.30011],
    [1.10805, -0.267655, 1.30659],
    [1.1286, -0.249717, 1.31177],
    [1.14855, -0.231125, 1.31572],
    [1.16792, -0.211981, 1.31852],
    [1.18675, -0.192389, 1.32024],
    [1.20507, -0.172455, 1.32098],
    [1.22292, -0.152285, 1.32083],
    [1.24033, -0.131986, 1.31991],
    [1.25733, -0.111666, 1.31831],
    [1.27394, -0.09143, 1.31617],
    [1.29019, -0.0713828, 1.31359],
    [1.3061, -0.0516274, 1.31072],
    [1.32171, -0.0322642, 1.30768],
    [1.33702, -0.0133912, 1.30461],
    [1.35206, 0.00489687, 1.30165],
    [1.36686, 0.0225086, 1.29892],
    [1.38143, 0.0393567, 1.29658],
    [1.39579, 0.0553577, 1.29475],
    [1.40996, 0.0704331, 1.29357],
    [1.42396, 0.0845094, 1.29317],
    [1.43779, 0.0975183, 1.29367],
    [1.45149, 0.109398, 1.29519],
    [1.46506, 0.120091, 1.29784],
    [1.47851, 0.12955, 1.30171],
    [1.49188, 0.13773, 1.30689],
    [1.50516, 0.144598, 1.31346],
    [1.51837, 0.150123, 1.32148],
    [1.53152, 0.154287, 1.33101],
    [1.54464, 0.157074, 1.34207],
    [1.55773, 0.158477, 1.3547],
    [1.57081, 0.158499, 1.3689],
    [1.5708, 0.135319, 1.3786],
    [1.5708, 0.112882, 1.38669],
    [1.5708, 0.091162, 1.39349],
    [1.5708, 0.0701639, 1.399],
    [1.5708, 0.0498969, 1.40324],
    [1.5708, 0.030371, 1.40622],
    [1.5708, 0.011597, 1.40794],
    [1.5708, -0.00641409, 1.40842],
    [1.5708, -0.0236504, 1.40765],
    [1.5708, -0.0400999, 1.40564],
    [1.5708, -0.0557503, 1.40238],
    [1.5708, -0.0705889, 1.39788],
    [1.5708, -0.0846027, 1.39213],
    [1.5708, -0.0977785, 1.38513],
    [1.5708, -0.110103, 1.37686],
    [1.5708, -0.121562, 1.36733],
    [1.5708, -0.13214, 1.3565],
    [1.5708, -0.141824, 1.34437],
    [1.5708, -0.150596, 1.33092],
    [1.5708, -0.158441, 1.31612],
    [1.5708, -0.165339, 1.29995],
    [1.5708, -0.171271, 1.28236],
    [1.5708, -0.176214, 1.26333],
    [1.5708, -0.180144, 1.24281],
    [1.5708, -0.183034, 1.22074],
    [1.5708, -0.184851, 1.19707],
    [1.5708, -0.18556, 1.17171],
    [1.5708, -0.185117, 1.14459],
    [1.5708, -0.183473, 1.11559],
    [1.5708, -0.180568, 1.0846],
    [1.5708, -0.176331, 1.05148],
    [1.5708, -0.170674, 1.01604],
    [1.5708, -0.16349, 0.978062],
    [1.5708, -0.154644, 0.937282],
    [1.5708, -0.143966, 0.893352],
    [1.5708, -0.131233, 0.845829],
    [1.5708, -0.116148, 0.794121]
])

    print(dataaa.shape)
    pass
    
   
   

def sysCall_actuation():
    global dataaa
    total = 9.7  
    #global previous_time
    
    self.curr_time= sim.getSimulationTime() - start_time

    if ((self.curr_time-self.previous_time)>=0.1 and self.j<97):
        new_position1= dataaa[self.j,0]
        new_position2= -dataaa[self.j,1]
        new_position3= -dataaa[self.j,2]
        sim.setJointTargetPosition(self.q1_handle, new_position1)
        sim.setJointTargetPosition(self.q2_handle, new_position2)
        sim.setJointTargetPosition(self.q3_handle, new_position3)
        #print("new_position1", new_position1*180/3.14)
        #print("new_position2", new_position2*180/3.14)
        #print("new_position3", new_position3*180/3.14)

        print(self.j)
        self.j=self.j+1
        self.previous_time= self.curr_time
    if self.j >= 97:
        new_position1= dataaa[-1,0]
        new_position2= -dataaa[-1,1]
        new_position3= -dataaa[-1,2]
        sim.setJointTargetPosition(self.q1_handle, new_position1)
        sim.setJointTargetPosition(self.q2_handle, new_position2)
        sim.setJointTargetPosition(self.q3_handle, new_position3)

        
    
    #print(self.previous_time)
    
    
    pass
    
    
 
def task_space(X0, Xf, Tf, Ts):
    # Generate circular trajectory
    X_matrix = task_traj_circle(X0, Xf, Tf, Ts)
    
    # Initialize the joint configuration matrix
    qmatrix = np.zeros(X_matrix.shape)
    m, n = X_matrix.shape
    
    # Initial joint configuration
    q0 = np.array([1.0, 50.0, 1.0])
    
    for i in range(m):
        X_desired = X_matrix[i, :]
        
        # Compute joint angles using inverse kinematics
        q = inverse_kinematics_newton_raphson(q0, X_desired)
        
        # Compute actual position from joint angles
        X_actual = forward_position_kinematics(q[0], q[1], q[2])
        
        # Store the joint angles
        qmatrix[i, :] = q
        
        # Update the previous joint configuration
        q0 = q
        
    return qmatrix
    
def task_traj_circle(X0, Xf, Tf, Ts):
    # Convert X0 and Xf to numpy arrays to enable element-wise operations
    X0 = np.array(X0)
    Xf = np.array(Xf)
    
    # Generate time array
    t = np.arange(0, Tf, Ts)
    
    # Calculate the radius based on the distance between X0 and Xf
    radius = np.linalg.norm(Xf - X0) / 2
    
    # Create circular trajectory points
    X_matrix = np.array([
        X0[0] + radius * np.cos(t), 
        X0[1] + radius * np.sin(t), 
        X0[2] * np.ones_like(t)
    ]).T  # Transpose to get the correct shape

    return X_matrix
    
def inverse_kinematics_newton_raphson(q, X_desired):
    error = 0
    for iter in range(1, 100 + 1):
        # Calculate current end-effector position
        X_current = forward_position_kinematics(q)

        #Calculate error
        error = {X_desired[1] - X_current[1], X_desired[2] - X_current[2]}

        # Check convergence
        if (error[0]**2 + error[1]**2 )**0.5 < self.tol:
            break
        end

        #Compute the inverse Jacobian
        J_inv = inverse_jacobian_matrix(q)

        #Update joint angles using Newton-Raphson
        delta_q = {0, 0, 0}
        for i in range(len(q)):
            for j in range(len(error)):
                delta_q[i] = delta_q[i] + J_inv[i][j] * error[j]
            end
        end

        #Update joint angles
        for i in range(len(q)):
            q[i] = q[i] + delta_q[i]
        end
    end

    return q



def forward_position_kinematics(q):
    L1 = 0.645
    L2 = 0.228
    L3 = 0.1365
    L4 = L1 + 0.1 - 0.031

    # Define the DH parameters for each joint
    DH_table = np.array([
        [q[1], L1, 0, 0],    # Revolute joint 1
        [0, q[2], L2, 0],    # Prismatic joint 2
        [q[2], -L4, L3, 0]   # Revolute joint 3
    ])
    
    # Initialize the total transformation matrix
    T_total = np.eye(4)
    
    # Loop through the DH table and multiply the transformation matrices
    for i in range(DH_table.shape[0]):
        theta = DH_table[i, 0]
        d = DH_table[i, 1]
        a = DH_table[i, 2]
        alpha = DH_table[i, 3]
        
        # Call the transformation function for each joint
        T_i = transformation_func(theta, d, a, alpha)
        T_total = np.dot(T_total, T_i)  # Matrix multiplication

    # Extract the end-effector position (Px, Py, Pz)
    Px = T_total[0, 3] * 1000 + 79  # X position in mm with offset
    Py = T_total[1, 3] * 1000        # Y position in mm
    Pz = T_total[2, 3] * 1000        # Z position in mm
    
    return np.array([Px, Py, Pz])

def transformation_func(theta, d, a, alpha):
    """
    Compute the homogeneous transformation matrix based on DH parameters.

    Parameters:
        theta (float): Joint angle (rotation about the z-axis).
        d (float): Link offset (translation along the z-axis).
        a (float): Link length (translation along the x-axis).
        alpha (float): Link twist (rotation about the x-axis).

    Returns:
        np.ndarray: The 4x4 homogeneous transformation matrix.
    """
    # Compute the homogeneous transformation matrix
    T = np.array([
        [np.cos(theta),            -np.sin(theta) * np.cos(alpha),   np.sin(theta) * np.sin(alpha),  a * np.cos(theta)],
        [np.sin(theta),            np.cos(theta) * np.cos(alpha),    -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
        [0,                        np.sin(alpha),                      np.cos(alpha),                  d],
        [0,                        0,                                   0,                              1]
    ])
    return T
    