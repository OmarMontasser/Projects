% Define joint angles (example values)
joint_angles = qmatrix;

% Serial Port Configuration
serialPort = 'COM6'; % Replace with your Arduino's COM port
baudRate = 9600;     % Must match the Arduino's baud rate

% Open the serial connection
arduino = serialport(serialPort, baudRate);

% Sending joint angles
for i = 1:size(joint_angles, 1)
    % Format the data as a comma-separated string with a newline
    data = sprintf('%.3f,%.3f,%.3f\n', joint_angles(i, 1), joint_angles(i, 2), joint_angles(i, 3));
    disp(['Sending data: ', data]);
    
    % Send the data to the Arduino
    write(arduino, data, "string");
    
    % Pause to allow Arduino to process
    pause(1);
    
    % Read response from Arduino
    if arduino.NumBytesAvailable > 0
        response = readline(arduino);
        disp(['Arduino Response: ', response]);
    end
end


% Close the connection (optional, can be skipped if reused later)
clear arduino;
