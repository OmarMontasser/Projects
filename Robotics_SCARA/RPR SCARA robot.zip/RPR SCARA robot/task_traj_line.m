function Task_Space = task_traj_line(X0, Xf, Tf, Ts)
    % Input Parameters:
    % X0 - Initial position as [x0, y0, z0]
    % Xf - Final position as [xf, yf, zf]
    % Tf - Total time for trajectory (seconds)
    % Ts - Sampling time (seconds)
    
    % Time vector
    t = 0:Ts:Tf;
    num_points = length(t);

    % Preallocate Task_Space matrix
    Task_Space = zeros(num_points, 3);

    % Compute linear interpolation for each coordinate
    for i = 1:3
        Task_Space(:, i) = linspace(X0(i), Xf(i), num_points);
    end
end
