function X = forward_Position_kinematics(q1, q2, q3)
    % Link lengths
    L1 = 0.645;
    L2 = 0.228;
    L3 = 0.1365;
    L4 = L1 + 0.1 - 0.031 + 0.025;
    
    % Define the DH parameters for each joint
    DH_table = [q1, L1, 0, 0;     % Revolute joint 1
                0, q2, L2, 0;     % Prismatic joint 2
                q3, -L4, L3, 0];  % Revolute joint 3
       
    % Initialize the total transformation matrix
    T_total = eye(4);
    
    % Loop through the DH table and multiply the transformation matrices
    for i = 1:size(DH_table, 1)
        theta = DH_table(i, 1);
        d = DH_table(i, 2);
        a = DH_table(i, 3);
        alpha = DH_table(i, 4);
        
        % Call the transformation function for each joint
        T_i = transformation_func(theta, d, a, alpha);
        T_total = T_total * T_i;
    end
    
    % Extract the end-effector position (Px, Py, Pz)
    Px = T_total(1, 4) * 1000 + 79;  % X position in mm with offset
    Py = T_total(2, 4) * 1000;       % Y position in mm
    Pz = T_total(3, 4) * 1000;       % Z position in mm
    X = [Px; Py; Pz]; % Make sure X is a column vector for compatibility
end
