function row = extractRow(time)

    idx = round(time * 10) + 1; % Calculate the row index
    if idx > size(qmatrix, 1)    % Prevent out-of-bounds errors
        row = zeros(1, size(qmatrix, 2)); % Default if index exceeds matrix size
    else
        row = qmatrix(idx, :);  % Extract the row
    end
end