function q_out = getin_scale(q)
    while q > 2*pi
        q = q - 2*pi;
    end
    while q < 0
        q = q + 2*pi;
    end
    q_out = q; % Ensure the output is assigned to the function variable
end