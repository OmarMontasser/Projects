function Task_Space = task_traj_circle(X0, Xf, Tf, Ts)
    if Tf > 20
        error('Tf should not exceed 10 seconds to avoid excessive computations.');
    end
    if length(X0) ~= 3 || length(Xf) ~= 3
        error('X0 and Xf must both be 3x1 vectors [x; y; z].');
    end

    % Time vector
    t = 0:Ts:Tf;

    % Phase 1: Linear motion in Z (prismatic joint movement)
    T_phase1 = Tf / 2; % Allocate half the time for Z motion
    t1 = 0:Ts:T_phase1; % Time vector for phase 1
    Z = linspace(X0(3), Xf(3), length(t1)); % Linear interpolation for Z
    X_linear = X0(1) * ones(1, length(t1)); % X remains constant in Z phase
    Y_linear = X0(2) * ones(1, length(t1)); % Y remains constant in Z phase

    % Phase 2: Circular motion in the X-Y plane
    T_phase2 = Tf / 2; % Allocate other half for circular motion
    t2 = T_phase1+Ts:Ts:Tf; % Time vector for phase 2
    radius = norm([Xf(1) - X0(1), Xf(2) - X0(2)]) / 2; % Radius of circle (halfway between X0 and Xf)
    center = [(X0(1) + Xf(1)) / 2, (X0(2) + Xf(2)) / 2]; % Circle center
    omega = pi / T_phase2; % Angular velocity for half-circle

    % Circular motion
    theta_start = atan2(X0(2) - center(2), X0(1) - center(1)); % Starting angle
    theta_end = atan2(Xf(2) - center(2), Xf(1) - center(1)); % Ending angle
    theta = linspace(theta_start, theta_end, length(t2));
    X_circular = center(1) + radius * cos(theta); % X trajectory
    Y_circular = center(2) + radius * sin(theta); % Y trajectory
    Z_circular = Xf(3) * ones(1, length(t2)); % Constant Z during circular motion

    % Combine trajectories
    Task_Space = [ ...
        [X_linear', Y_linear', Z']; ... % Phase 1
        [X_circular', Y_circular', Z_circular'] ... % Phase 2
    ];
end
