function J_inv = inverse_jacobian_matrix(q)
    % Use the generated numeric function to evaluate the Jacobian
    J_numeric = numeric_jacobian_func(q(1), q(2), q(3));

    % Compute inverse or pseudo-inverse based on Jacobian size
    if(det(J_numeric)==0)
        J_inv = zeros(size(J_numeric));
    else 
    if rank(J_numeric) == size(J_numeric, 1)
        J_inv = inv(J_numeric); % Exact inverse
    else
        J_inv = pinv(J_numeric); % Pseudo-inverse
    end
    end
end